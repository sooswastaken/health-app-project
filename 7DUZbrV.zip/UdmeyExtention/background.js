chrome.webRequest.onCompleted.addListener(
    function(details) {
        const url = details.url;

        const isVTT = url.includes('.vtt');
        const isUdemyCDN = url.includes('udemycdn.com');
        const isNotThumbSprites = !url.includes('thumb-sprites');

        if (isVTT && isUdemyCDN && isNotThumbSprites) {
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                const activeTab = tabs[0];
                if (activeTab) {
                    chrome.scripting.executeScript({
                        target: {tabId: activeTab.id},
                        func: function() {
                            const currentItem = document.querySelector('.curriculum-item-link--curriculum-item--KX9MD.curriculum-item-link--is-current--31BPo');
                            const titleElement = currentItem ? currentItem.querySelector('[data-purpose="item-title"]') : null;
                            return titleElement ? titleElement.textContent : '';
                        }
                    }, function(results) {
                        if (chrome.runtime.lastError) {
                            console.error(chrome.runtime.lastError);
                            return;
                        }
                        const title = results[0].result;
                        const number = parseInt(title.split('.')[0]);

                        chrome.storage.local.get(['subtitles'], function(result) {
                            let subtitles = result.subtitles || [];
                            
                            const existingSubtitle = subtitles.find(s => s.title === title);
                            if (!existingSubtitle) {
                                subtitles.push({ url: url, title: title, number: number });
                                subtitles.sort((a, b) => a.number - b.number);
                                chrome.storage.local.set({ subtitles: subtitles });
                            }
                        });
                    });
                }
            });
        }
    },
    { urls: ["<all_urls>"] },
    []
);
