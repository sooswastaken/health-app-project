chrome.storage.local.get(['subtitles'], function(result) {
    let subtitles = result.subtitles || [];
    subtitles.forEach(sub => {
        let li = document.createElement('li');
        let subtitleLink = document.createElement('a');
        subtitleLink.href = sub.url;
        subtitleLink.target = "_blank";
        subtitleLink.innerText = sub.title;
        li.appendChild(subtitleLink);
        subtitleList.appendChild(li);
    });
});

document.getElementById("exportSubtitles").addEventListener("click", function() {
    chrome.storage.local.get(['subtitles'], function(result) {
        let subtitles = result.subtitles || [];
        let fetchedSubtitles = [];
        
        const fetchSubtitle = (url, callback) => {
            let xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    callback(xhr.responseText);
                }
            };
            xhr.send();
        };

        subtitles.forEach((sub, index) => {
            fetchSubtitle(sub.url, content => {
                fetchedSubtitles.push({
                    title: sub.title,
                    content: content
                });

                if (fetchedSubtitles.length === subtitles.length) {
                    let textToExport = fetchedSubtitles.map(sub => `Title: ${sub.title}\n\n${sub.content}\n\n`).join("\n");
                    let blob = new Blob([textToExport], {type: "text/plain"});
                    let url = URL.createObjectURL(blob);
                    
                    let downloadLink = document.createElement('a');
                    downloadLink.href = url;
                    downloadLink.download = 'subtitles.txt';
                    document.body.appendChild(downloadLink);
                    downloadLink.click();
                    document.body.removeChild(downloadLink);
                }
            });
        });
    });
});

document.getElementById("clearList").addEventListener("click", function() {
    chrome.storage.local.set({ subtitles: [] }, function() {
        document.getElementById("subtitleList").innerHTML = '';
    });
});
